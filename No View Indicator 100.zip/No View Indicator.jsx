/*
  No View Indicator
    (C) あかつきみさき(みくちぃP)

  このスクリプトについて
    インジケーターを10800秒に設定します.

  使用方法
    スクリプトファイルの実行より実行してください.

  動作環境
    Adobe After Effects CS5以上

  バージョン情報
    2016/02/11 Ver 1.0.0 Release
 */

(function() {
  app.project.activeItem.time = 10800;
}).call(this);
